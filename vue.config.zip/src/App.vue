<template>
  <PaginaPrincipal></PaginaPrincipal>
  <imagensDiv></imagensDiv>
  <br>
  <TableDiv></TableDiv>
</template>

<script>
import imagensDiv from './components/Imagens.vue';
import TableDiv from './components/TableCat.vue';
import PaginaPrincipalComponent from './components/PaginaPrincipal.vue';

export default {
  name: "App",
  components: {
    imagensDiv,
    TableDiv,
    PaginaPrincipal: PaginaPrincipalComponent
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
