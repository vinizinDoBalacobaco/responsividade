<template>
    <div id="pagDiv"></div>
</template>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container {
  text-align: center;
  margin-top: 50px;
}
body {
    margin: 50px;
    padding: 0;
}

@keyframes bg {
    0% {
        background: rgba(25, 220, 234, 0);
    }

    100% {
        background-image: #000000;
    }
}


img {
    border-radius: 10px;
    width: 40%;
    height: auto;
    margin: 5px;
}

#imggrande {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 80%;
    height: auto;
}


@media screen and (max-width: 850px) {
    tabela {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    table {
        size: 120%;
        margin-left: auto;
        margin-right: auto;
        border-collapse: collapse;
        margin-top: 50px;
    }

    table td {
        text-align: center;
    }

    #imagem1 {
        background-image: none;
        animation: bg 1s cubic-bezier(0.230, 1.000, 0.320, 1.000) infinite reverse both;
    }

    #imagem2 {
        background-image: none;
    }

    #imagem3 {
        background-image: none;
    }

    #imagem4 {
        background-image: none;
    }

    #div2 {
        display: flex;
        flex-direction: column;
        width: 100%;
        justify-content: center;
        align-items: center;
    }

    #div2 img {
        width: 60%;
        height: auto;
    }

    #div1 h4 {
        transform: scale(70%);
        transition: 1s;
    }

    #div1 h1 {
        transform: scale(150%);
        transition-duration: 1s;
        margin-bottom: 0;
    }

    #video {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
    }

    #video iframe {
        width: 60%;
        height: 200px;
        margin-top: -15px;
    }

    #div1 {
        margin-bottom: 0px;
    }

    #div1 img {
        width: 60%;
        margin-bottom: 5px;
        height: auto;
    }

}

@media (max-width: 400px) {
    #div2 img {
        width: 90%;
        height: auto;
    }

    #div1 h4 {
        display: none;
    }

    #div1 h1 {
        transform: scale(150%);
        transition-duration: 1s;
        margin-bottom: 50px;
    }

    #video {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
    }

    #video iframe {
        width: 90%;
        height: 120px;
        margin-top: -15px;
    }

    #div1 img {
        width: 90%;
        margin-bottom: 5px;
        height: auto;
    }
}
</style>
