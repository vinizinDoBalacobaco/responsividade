<template>
  <body>
    <div id="div1">
      <h1>Titulo</h1>
      <h4>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias rem ipsam consequatur nostrum. Est architecto
        ab.</h4>
      <img src="image3-3.png" id="imggrande" alt="">
    </div>

    <div id="div2">
      <img src="respingo-colorido-abstrato-3d-background-generativo-ai-background_60438-2509.avif" alt="">
      <img src="fundo-de-cor-brilhante-abstrato-generative-ai_155807-1706.jpg" alt="">
    </div>

    <div id="video">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/hijP54QlSVk?si=7gyYKLKZN1hZ3FNA"
        title="YouTube video player" frameborder="0"
        allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen></iframe>
    </div>



    <div>
      <table border="1px" align="center">
        <tr>
          <th>Item</th>
          <th>Nome do Gato</th>
          <th>Imagem</th>
        </tr>
        <tr>
          <th>1</th>
          <td>Sphynx</td>
          <td id="imagem1"><img src="https://t1.ea.ltmcdn.com/pt/posts/4/2/3/sphynx_21324_1_600.webp"></td>
        </tr>
        <tr>
          <td>2</td>
          <td>Peterbald</td>
          <td id="imagem2"><img src="https://t2.ea.ltmcdn.com/pt/posts/4/2/3/peterbald_21324_7_600.webp"></td>
        </tr>
        <tr>
          <td>3</td>
          <td>Munchkin</td>
          <td id="imagem3"><img src="https://t1.ea.ltmcdn.com/pt/posts/4/2/3/munchkin_21324_8_600.webp"></td>
        </tr>
        <tr>
          <td>4</td>
          <td>Cornish Rex</td>
          <td id="imagem4"><img src="https://t2.ea.ltmcdn.com/pt/posts/4/2/3/cornish_rex_21324_9_600.webp"></td>
        </tr>
      </table>
    </div>
  </body>
</template>
  
<script>
export default {
  name: 'HelloWorld',
};


</script>
<style scoped>
.container {
  text-align: center;
  margin-top: 50px;
}
body {
    margin: 50px;
    padding: 0;
}

@keyframes bg {
    0% {
        background: rgba(25, 220, 234, 0);
    }

    100% {
        background-image: #000000;
    }
}

tabela {
    display: flex;
    justify-content: center;
    align-items: center;
}

table {
    margin-left: auto;
    margin-right: auto;
    border-collapse: collapse;
    margin-top: 50px;
}

table td {
    text-align: center;
}

#imagem1 {
    background-image: url(https://t1.ea.ltmcdn.com/pt/posts/4/2/3/sphynx_21324_1_600.webp);
}

#imagem2 {
    background-image: url(https://t2.ea.ltmcdn.com/pt/posts/4/2/3/peterbald_21324_7_600.webp);
}

#imagem3 {
    background-image: url(https://t1.ea.ltmcdn.com/pt/posts/4/2/3/munchkin_21324_8_600.webp);
}

#imagem4 {
    background-image: url(https://t2.ea.ltmcdn.com/pt/posts/4/2/3/cornish_rex_21324_9_600.webp);
}

img {
    border-radius: 10px;
    width: 40%;
    height: auto;
    margin: 5px;
}

#imggrande {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 80%;
    height: auto;
}

#video {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

#video iframe {
    width: 80%;
    height: 455px;
    border-radius: 20px;
}

#div1 {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-bottom: 30px;
}

#div1 h4 {
    font-size: xx-large;
    transform: scale(100%);
    transition-duration: 1s;
}

#div1 h1 {
    transform: scale(190%);
    transition-duration: 1s;
}

#div2 {
    display: flex;
    justify-content: center;
    align-items: center;
}

@media screen and (max-width: 850px) {
    tabela {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    table {
        size: 120%;
        margin-left: auto;
        margin-right: auto;
        border-collapse: collapse;
        margin-top: 50px;
    }

    table td {
        text-align: center;
    }

    #imagem1 {
        background-image: none;
        animation: bg 1s cubic-bezier(0.230, 1.000, 0.320, 1.000) infinite reverse both;
    }

    #imagem2 {
        background-image: none;
    }

    #imagem3 {
        background-image: none;
    }

    #imagem4 {
        background-image: none;
    }

    #div2 {
        display: flex;
        flex-direction: column;
        width: 100%;
        justify-content: center;
        align-items: center;
    }

    #div2 img {
        width: 60%;
        height: auto;
    }

    #div1 h4 {
        transform: scale(70%);
        transition: 1s;
    }

    #div1 h1 {
        transform: scale(150%);
        transition-duration: 1s;
        margin-bottom: 0;
    }

    #video {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
    }

    #video iframe {
        width: 60%;
        height: 200px;
        margin-top: -15px;
    }

    #div1 {
        margin-bottom: 0px;
    }

    #div1 img {
        width: 60%;
        margin-bottom: 5px;
        height: auto;
    }

}

@media (max-width: 400px) {
    #div2 img {
        width: 90%;
        height: auto;
    }

    #div1 h4 {
        display: none;
    }

    #div1 h1 {
        transform: scale(150%);
        transition-duration: 1s;
        margin-bottom: 50px;
    }

    #video {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
    }

    #video iframe {
        width: 90%;
        height: 120px;
        margin-top: -15px;
    }

    #div1 img {
        width: 90%;
        margin-bottom: 5px;
        height: auto;
    }
}
</style>

  