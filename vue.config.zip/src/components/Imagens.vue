<template>
      <div id="imagensDiv">
      <div id="div1">
        <h1>Titulo</h1>
      </div>
  
      <div id="div2">
        <img src="respingo-colorido-abstrato-3d-background-generativo-ai-background_60438-2509.avif" alt="">
        <img src="fundo-de-cor-brilhante-abstrato-generative-ai_155807-1706.jpg" alt="">
      </div>
  
      <div id="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/hijP54QlSVk?si=7gyYKLKZN1hZ3FNA"
          title="YouTube video player" frameborder="0"
          allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowfullscreen></iframe>
      </div>
    </div>
  </template>
  <style scoped>
#video {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

#video iframe {
    width: 80%;
    height: 455px;
    border-radius: 20px;
}

#div1 {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-bottom: 30px;
}

#div1 h4 {
    font-size: xx-large;
    transform: scale(100%);
    transition-duration: 1s;
}

#div1 h1 {
    transform: scale(190%);
    transition-duration: 1s;
}

#div2 {
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>